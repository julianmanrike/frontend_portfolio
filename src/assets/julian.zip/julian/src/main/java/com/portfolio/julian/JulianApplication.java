package com.portfolio.julian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JulianApplication {

	public static void main(String[] args) {
		SpringApplication.run(JulianApplication.class, args);
	}

}
