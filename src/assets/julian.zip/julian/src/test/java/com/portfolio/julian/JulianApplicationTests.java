package com.portfolio.julian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JulianApplicationTests {

	@Test
	void contextLoads() {
	}

}
